namespace WildBall.Inputs
{
    public class GlobalInputVars
    {
        #region

        public const string Play = "Play";

        #endregion
    }
}