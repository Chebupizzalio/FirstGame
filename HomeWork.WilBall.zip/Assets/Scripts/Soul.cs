using UnityEngine;

namespace WildBall
{
    public class Soul : MonoBehaviour
    {
    }
}