using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    [SerializeField] private GameObject FistScreen;
    [SerializeField] private GameObject SecondScreen;

    private GameObject currentScreen;

    private void Start()
    {
        FistScreen.SetActive(true);
        SecondScreen.SetActive(false);
        currentScreen = FistScreen;
    }

    public void ChangeState(GameObject state)
    {
        if (currentScreen != null)
        {
            currentScreen.SetActive(false);
            state.SetActive(true);
            currentScreen = state;
        }
    }

    public void OnPause(GameObject state)
    {

        if (currentScreen != null)
        {
            currentScreen.SetActive(false);
            state.SetActive(true);
            currentScreen = state;
            Time.timeScale = 0f;
        }
    }

    public void OnContinue(GameObject state)
    {
        if (currentScreen != null)
        {
            currentScreen.SetActive(false);
            state.SetActive(true);
            currentScreen = state;
            Time.timeScale = 1f;
        }
    }
}
